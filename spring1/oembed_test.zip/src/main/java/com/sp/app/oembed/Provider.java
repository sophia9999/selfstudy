package com.sp.app.oembed;

import java.util.Map;

public interface Provider {

	public Map<String, Object> getProviderMap() throws Exception;
	
}
